package com.tejas.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tejas.models.Cart;
import com.tejas.models.Product;
import com.tejas.models.User;
@Repository
public interface CartRepository extends JpaRepository<Cart, Long>{
	//to add product to cart as per product and user
	Optional<Cart> findByProductAndUser(Product product, User user);
	
	//custom query in spring boot to get product as per user id
	@Query("SELECT c.product FROM Cart c WHERE c.user.id = :userId")
	List<Product> findProductsByUserId(@Param("userId") Long userId);	
}




