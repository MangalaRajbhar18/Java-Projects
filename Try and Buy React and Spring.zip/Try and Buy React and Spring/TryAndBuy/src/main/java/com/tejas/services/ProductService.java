package com.tejas.services;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tejas.models.Category;
import com.tejas.models.Product;
import com.tejas.models.User;
import com.tejas.repositories.CategoryRepository;
import com.tejas.repositories.ProductRepository;
import com.tejas.repositories.UserRepository;
import com.tejas.responsewrapper.MyResponseWrapper;

@Service
public class ProductService {
	@Autowired
	ProductRepository productRepository;
	@Autowired
	MyResponseWrapper responseWrapper;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CategoryRepository categoryRepository;
	
	
	private static final String UPLOAD_DIR = System.getProperty("user.dir") + "/uploads/images/";
	
	public ResponseEntity<?> addProduct(String productJson, MultipartFile file) throws IOException
	{
		ObjectMapper mapper = new ObjectMapper();
		Product product = mapper.readValue(productJson, Product.class);	
		
		User user=userRepository.findById(product.getUser().getId()).get();
		Category category=categoryRepository.findById(product.getCategory().getId()).get();
		
		 File uploadDir = new File(UPLOAD_DIR);
	        if (!uploadDir.exists()) {
	            uploadDir.mkdirs();
	        }
	        
	        
	        String originalFilename = file.getOriginalFilename();
	        Path filePath = Paths.get(UPLOAD_DIR, originalFilename);
	        Files.write(filePath, file.getBytes());

	        // Save filename to product
	        product.setImageName(originalFilename);
	        product.setUser(user);
	        product.setCategory(category);
	        Product savedProduct = productRepository.save(product);

	        // Wrap response
	        responseWrapper.setMessage("Following product added");
	        responseWrapper.setData(savedProduct);

	        return new ResponseEntity<>(responseWrapper, HttpStatus.CREATED);
	}
	
	public ResponseEntity<?> getAllProductsForPerticularUser(long userId)
	{
		User user=userRepository.findById(userId).get();
		List<Product> allProducts=productRepository.findByUser(user);
		responseWrapper.setMessage("Following product found");
        responseWrapper.setData(allProducts);

        return new ResponseEntity<>(responseWrapper, HttpStatus.FOUND);
	}
	
	public ResponseEntity<?> deleteProductById(long productId)
	{
		Optional<Product> productExisting=productRepository.findById(productId);
		if(productExisting.isPresent())
		{
			productRepository.deleteById(productId);
		}
		else
		{
			responseWrapper.setMessage("Product With Id "+productId+" not exist");
	        responseWrapper.setData(null);
	        return new ResponseEntity<>(responseWrapper, HttpStatus.NOT_FOUND);
		}
		
		Optional<Product> product=productRepository.findById(productId);
		if(product.isPresent())
		{
			//failed delete
			responseWrapper.setMessage("Product Deletion failed");
	        responseWrapper.setData(null);
	        return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else
		{
			//deleted
			responseWrapper.setMessage("Product Deleted successfully");
	        responseWrapper.setData(true);
	        return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
		}
	}
	
	public ResponseEntity<?> updateProductById(long productId, String productJson, MultipartFile file) throws IOException
	{
		ObjectMapper mapper = new ObjectMapper();
		Product newProduct = mapper.readValue(productJson, Product.class);	
	    Optional<Product> existingProduct=productRepository.findById(productId);
	    Category category=categoryRepository.findById(newProduct.getCategory().getId()).get();
	    if(existingProduct.isPresent())
	    {
	    	
	    	
	    	String originalFilename = file.getOriginalFilename();
	        Path filePath = Paths.get(UPLOAD_DIR, originalFilename);
	        Files.write(filePath, file.getBytes());
	        
	        newProduct.setId(productId);
	    	newProduct.setCreatedAt(existingProduct.get().getCreatedAt());
	    	newProduct.setUser(existingProduct.get().getUser());
	    	newProduct.setCategory(category);
	    	newProduct.setImageName(originalFilename);
	    	
	    	Product updatedProduct = productRepository.save(newProduct);

	        // Wrap response
	        responseWrapper.setMessage("Following product updated");
	        responseWrapper.setData(updatedProduct);

	        return new ResponseEntity<>(responseWrapper, HttpStatus.CREATED);
	    }
	    else
	    {
	    	//product with given id not exists
	    	responseWrapper.setMessage("Product With Id "+productId+" not exist");
	        responseWrapper.setData(null);
	        return new ResponseEntity<>(responseWrapper, HttpStatus.NOT_FOUND);
	    }
	}
	
	
	public ResponseEntity<?> getProductById(long productId)
	{
		Optional<Product> existingProduct=productRepository.findById(productId);
		if(existingProduct.isPresent())
		{
			responseWrapper.setMessage("Following product Found");
	        responseWrapper.setData(existingProduct.get());
	        return new ResponseEntity<>(responseWrapper, HttpStatus.FOUND);
		}
		else
		{
			responseWrapper.setMessage("Product With Id "+productId+" not exist");
	        responseWrapper.setData(null);
	        return new ResponseEntity<>(responseWrapper, HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<?> getAllProducts()
	{
		List<Product> products=productRepository.findAll();
		responseWrapper.setMessage("Following products found");
		responseWrapper.setData(products);
		return new ResponseEntity<>(responseWrapper, HttpStatus.FOUND);
	}
	

}















