package com.tejas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tejas.models.Category;
import com.tejas.services.CategoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/vendors") //every api starts with this
@CrossOrigin("*")
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	
	@PostMapping("/manage-categories")
	public ResponseEntity<?> register(@RequestBody @Valid Category category)
	{
		return categoryService.addCategory(category);
	}
	
	@GetMapping("/manage-categories")
	public ResponseEntity<?> getAllCategories()
	{
		return categoryService.getAllCategories();
	}

}
