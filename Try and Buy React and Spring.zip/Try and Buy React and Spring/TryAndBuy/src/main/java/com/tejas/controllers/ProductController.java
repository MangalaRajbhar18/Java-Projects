package com.tejas.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tejas.models.Product;
import com.tejas.services.ProductService;

@RestController
@RequestMapping("/api/v1/products") //every api starts with this
@CrossOrigin("*")
public class ProductController {
	@Autowired
	ProductService productService;

	
	@PostMapping("")
	public ResponseEntity<?> addProduct(@RequestPart("product") String productJson, @RequestParam("file") MultipartFile file) throws IOException 
	{
		return productService.addProduct(productJson, file);
	}
	
	
	@PostMapping("/{userId}")
	public ResponseEntity<?> getAllProductsForPerticularUser(@PathVariable long userId)
	{
		return productService.getAllProductsForPerticularUser(userId);
	}
	
	@DeleteMapping("/{productId}")
	public ResponseEntity<?> deleteProductById(@PathVariable long productId)
	{
		return productService.deleteProductById(productId);
	}
	
	@PutMapping("/{productId}")
	public ResponseEntity<?> updateProductById(@PathVariable long productId,@RequestPart("product") String productJson,@RequestParam("file") MultipartFile file) throws IOException
	{
		return productService.updateProductById(productId, productJson, file);
	}
	
	@GetMapping("/{productId}")
	public ResponseEntity<?> getProductById(@PathVariable long productId)
	{
		return productService.getProductById(productId);
	}
	
	@GetMapping("")
	public ResponseEntity<?> getAllProducts()
	{
		return productService.getAllProducts();
	}


}







