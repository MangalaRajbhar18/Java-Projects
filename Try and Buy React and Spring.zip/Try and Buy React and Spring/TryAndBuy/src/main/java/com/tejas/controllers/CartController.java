package com.tejas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tejas.models.Cart;
import com.tejas.services.CartService;

@RestController
@RequestMapping("/api/v1/cart") //every api starts with this
@CrossOrigin("*")
public class CartController {
	@Autowired
	CartService cartService;
	
	@PostMapping("")
	private ResponseEntity<?> addToCart(@RequestBody Cart cart)
	{
		return cartService.addToCart(cart);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<?> getCartItemsForPerticularUser(@PathVariable long userId)
	{
		return cartService.getCartItemsForPerticularUser(userId);
	}

}
