package com.tejas.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.tejas.models.Address;
import com.tejas.models.User;
import com.tejas.repositories.AddressRepository;
import com.tejas.repositories.UserRepository;
import com.tejas.responsewrapper.MyResponseWrapper;

@Service
public class UserService {
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	MyResponseWrapper responseWrapper;
	
	public ResponseEntity<?> register(User user)
	{
		Optional<User> existingUser=userRepository.findByEmail(user.getEmail());
		if(existingUser.isPresent())
		{
			responseWrapper.setMessage("Email - "+ user.getEmail() + "already exists");
			responseWrapper.setData(true);
			return new ResponseEntity<>(responseWrapper, HttpStatus.CONFLICT);
		}
		else
		{
			Address address=user.getAddress();
			Address savedAddress=addressRepository.save(address);
			user.setAddress(savedAddress);
			User savedUser=userRepository.save(user);
			responseWrapper.setMessage("Registration Success!");
			responseWrapper.setData(savedUser);
			return new ResponseEntity<>(responseWrapper, HttpStatus.CREATED);
		}
		
	}
	
	
	public ResponseEntity<?> login(String email, String password)
	{
		Optional<User> user=userRepository.findByEmailAndPassword(email, password);
		if(user.isPresent())
		{
			responseWrapper.setMessage("Login Success!");
			responseWrapper.setData(user.get());
			return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
		}
		else
		{
			responseWrapper.setMessage("Wrong Credentials");
			responseWrapper.setData(null);
			return new ResponseEntity<>(responseWrapper, HttpStatus.NOT_FOUND);
		}
	}

}















