package com.tejas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.tejas.models.Cart;
import com.tejas.models.Product;
import com.tejas.models.User;
import com.tejas.repositories.AddressRepository;
import com.tejas.repositories.CartRepository;
import com.tejas.repositories.ProductRepository;
import com.tejas.repositories.UserRepository;
import com.tejas.responsewrapper.MyResponseWrapper;

@Service
public class CartService 
{
	@Autowired
	ProductRepository productRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CartRepository cartRepository;
	@Autowired
	MyResponseWrapper responseWrapper;

	//to add product into cart. we need which product to add and who is adding and quantity
	//so we need cart object that has id,user,product and quantity
	public ResponseEntity<?> addToCart(Cart cart)
	{
		
		Optional<User> user=userRepository.findById(cart.getUser().getId());
		Optional<Product> product=productRepository.findById(cart.getProduct().getId());
		Optional<Cart> existingProductInCart=cartRepository.findByProductAndUser(product.get(), user.get());
		if(existingProductInCart.isPresent())
		{
			responseWrapper.setMessage("Product already in the cart");
			responseWrapper.setData(false);
			return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else
		{
			if(user.isPresent() && product.isPresent())
			{
				cart.setUser(user.get());
				cart.setProduct(product.get());
				cartRepository.save(cart);
				responseWrapper.setMessage("Product added to the cart");
				responseWrapper.setData(true);
				return new ResponseEntity<>(responseWrapper, HttpStatus.CREATED);
			}
			else
			{
				responseWrapper.setMessage("failed to add product in the cart");
				responseWrapper.setData(null);
				return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
		
	}
	
	//getting products from cart for particular user 
	public ResponseEntity<?> getCartItemsForPerticularUser(long userId)
	{
		List<Product> cartItems=cartRepository.findProductsByUserId(userId);
		responseWrapper.setMessage("Follwoing item found for user is "+userId);
		responseWrapper.setData(cartItems);
		return new ResponseEntity<>(responseWrapper, HttpStatus.FOUND);
	}
	
}
