package com.tejas.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.tejas.TryAndBuyApplication;
import com.tejas.models.Category;
import com.tejas.repositories.CategoryRepository;
import com.tejas.responsewrapper.MyResponseWrapper;

@Service
public class CategoryService {

    private final TryAndBuyApplication tryAndBuyApplication;
	@Autowired
	CategoryRepository categoryRepository;
	@Autowired
	MyResponseWrapper responseWrapper;

    CategoryService(TryAndBuyApplication tryAndBuyApplication) {
        this.tryAndBuyApplication = tryAndBuyApplication;
    }
	
	public ResponseEntity<?> addCategory(Category category)
	{
		Optional<Category> existingCategory=categoryRepository.findByName(category.getName());
		if(existingCategory.isPresent())
		{
			responseWrapper.setMessage("Category " + category.getName() + " alredy exist");
			responseWrapper.setData(true);
			return new ResponseEntity<>(responseWrapper, HttpStatus.CONFLICT);
		}
		else
		{
			Category savedCategory=categoryRepository.save(category);
			responseWrapper.setMessage("Follwong category saved");
			responseWrapper.setData(savedCategory);
			return new ResponseEntity<>(responseWrapper, HttpStatus.CREATED);
		}
		
	}
	
	
	public ResponseEntity<?> getAllCategories()
	{
		List<Category> categories=categoryRepository.findAll();
		if(categories.size()>0)
		{
			responseWrapper.setMessage("following categories found");
			responseWrapper.setData(categories);
			return new ResponseEntity<>(responseWrapper, HttpStatus.FOUND);
		}
		else
		{
			responseWrapper.setMessage("there are no categories found");
			responseWrapper.setData(null);
			return new ResponseEntity<>(responseWrapper, HttpStatus.NOT_FOUND);
		}
	}

}











