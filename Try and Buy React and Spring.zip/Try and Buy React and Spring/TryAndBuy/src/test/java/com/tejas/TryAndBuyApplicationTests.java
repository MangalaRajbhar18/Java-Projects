package com.tejas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TryAndBuyApplicationTests {

	@Test
	void contextLoads() {
	}

}
